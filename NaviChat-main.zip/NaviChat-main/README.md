# NaviChat

XAMPP services used:
- Apache
- MySQL

Usage:
1. Import the sql database
2. Put the navichat folder into htdoc folder
3. Open web browser and go to localhost/navichat
