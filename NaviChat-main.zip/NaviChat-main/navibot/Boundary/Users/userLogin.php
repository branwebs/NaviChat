<?php
require_once '../../dbCfg.php';
require_once '../../Controller/Users/userLoginController.php';

$errors = [];
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $loginController = new UserLoginController();
    $errors = $loginController->processLogin($email, $password);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet"  href="../../css/login-register.css">
</head>

<body>
    <section>
        <div class="form-box">
            <h2 class="login-title">Login</h2>
            <form class="user-input" method="POST">
                <label for="email">Business Email:</label>
                <input type="email" name="email" id="email" required>
                <br>
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required>
                <!-- Display errors if any -->
                <?php if (!empty($errors)) : ?>
                    <div class="error-messages">
                        <?php foreach ($errors as $error) : ?>
                            <p><?php echo htmlspecialchars($error); ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <br>
                <input type="submit" name="login" class="submit-btn" value="Login">
            </form>

            <!-- Register -->
            <div class="links">
                    Don't have account? <a href="register.php">Sign Up Now</a>
            </div>
        </div>
    </section>
</body>

</html>

