
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User_dashboard</title>
    
    <!-- CSS links -->
    <link rel="stylesheet" type="text/css" href="../../css/userstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" 
    integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
<div class="header">
        <h1>NaviChat</h1>
        <a class="logout" href="../../Boundary/Users/logoutConfirmation.php" >
            <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
        </a>
    </div>
    <div class="sidebar">
        <ul>
            <li><a href="#">Manage Tickets</a></li>
            <li>
                <a href="#">Configure Chatbot &#9662;</a>
                <ul class="dropdown">
                    <li><a href="#">Manage Answer Templates</a></li>
                    <li><a href="#">Installation Guide</a></li>
                    <li><a href="#">Select Industry</a></li>
                </ul>
            </li>
            <li><a href="#">Live Chat</a></li>
            <li><a href="#">Trends</a></li>
            <li><a href="#">Analytics</a></li>
            <li><a href="#">Feedback</a></li>
            <li><a href="../../Boundary/Users/viewProfile.php">Profile</a></li>
            <li><a href="#">Subscription</a></li>
        </ul>
    </div>
    <div class="content">
        <!-- Content goes here -->
    </div>
</body>
</html>